alert("Its my first all index site, so ENJOY baby.......");
